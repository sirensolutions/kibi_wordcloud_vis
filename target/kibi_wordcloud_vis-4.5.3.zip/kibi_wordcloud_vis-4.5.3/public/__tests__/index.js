describe('Kibi Word Cloud', function () {
  require('./_vis');
});
