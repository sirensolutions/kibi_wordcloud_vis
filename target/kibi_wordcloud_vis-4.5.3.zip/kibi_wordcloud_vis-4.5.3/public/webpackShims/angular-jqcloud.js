require('bower_components/jqcloud2/src/jqcloud');
require('bower_components/jqcloud2/src/jqcloud.css');
require('bower_components/angular-jqcloud/angular-jqcloud');

require('ui/modules').get('kibana', ['angular-jqcloud']);
