require('../../node_modules/jqcloud2/src/jqcloud');
require('../../node_modules/jqcloud2/src/jqcloud.css');
require('../../node_modules/angular-jqcloud/angular-jqcloud');

require('ui/modules').get('kibana', ['angular-jqcloud']);
